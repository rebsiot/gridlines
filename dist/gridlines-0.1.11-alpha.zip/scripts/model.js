import {normalizeRange, formatRange} from "./coordinates.js";

export const MODULE_ID = "gridlines";
export const DATA_KEY = "state";
export const SCHEMA_VERSION = 1;
const MAX_RANGES = 500;
const MAX_FORMATS = 1000;

export const DEFAULT_AXES = Object.freeze({
  enabled: true, labels: true, majorEvery: 10, minorDivisions: 5,
  majorEveryX: 10, majorEveryY: 10, minorDivisionsX: 5, minorDivisionsY: 5, rulerMode: "auto",
  // cellSize is the legacy v0.1.5 square dimension. Keep it for reading old
  // Scene flags, but prefer the independent width/height on new saves.
  cellSize: null, cellWidth: null, cellHeight: null, linkCellDimensions: true,
  offsetX: 0, offsetY: 0,
  a1Row: 0, a1Col: 0,
  color: "#65baff", alpha: .65, majorWidth: 2, minorWidth: 1, coordinateScope: "major",
  colLabelSize: 11, rowLabelSize: 11, subLabelSize: 10,
  colLabelPosition: "top", rowLabelPosition: "left",
  colLabelColor: "#ffffff", rowLabelColor: "#ffffff", subLabelColor: "#fef3c7"
});

/** Optional axis fields maintain v0.1.1 Scene flags without a migration. */
export function normalizeAxes(value = {}) {
  const prior = (value && Object.keys(value).length > 0 && value.coordinateScope === undefined);
  const raw = value ?? {};
  const normalized = {...DEFAULT_AXES, ...raw, ...(prior ? {coordinateScope: "cell"} : {})};
  // Old Scenes store only cellSize. Null on a new axis means native sizing;
  // on an old Scene it inherits the legacy dimension until the GM saves.
  normalized.cellWidth = raw.cellWidth ?? raw.cellSize ?? null;
  normalized.cellHeight = raw.cellHeight ?? raw.cellSize ?? null;
  // Legacy Scenes keep the same column AND row spacing without a data migration.
  normalized.majorEveryX = raw.majorEveryX ?? raw.majorEvery ?? 10;
  normalized.majorEveryY = raw.majorEveryY ?? raw.majorEvery ?? 10;
  normalized.minorDivisionsX = raw.minorDivisionsX ?? raw.minorDivisions ?? 5;
  normalized.minorDivisionsY = raw.minorDivisionsY ?? raw.minorDivisions ?? 5;
  normalized.rulerMode = raw.rulerMode ?? "auto";
  return normalized;
}

export function validateAxes(value) {
  const a = normalizeAxes(value);
  const integer = (x, min, max) => Number.isInteger(x) && x >= min && x <= max;
  const finite = (x, min, max) => typeof x === "number" && Number.isFinite(x) && x >= min && x <= max;
  if (!["major", "cell"].includes(a.coordinateScope)) throw new Error("Invalid coordinate labeling mode");
  if (!integer(a.majorEvery, 1, 200) || !integer(a.minorDivisions, 1, 20))
    throw new Error("Major interval must be 1–200 cells, minor divisions 1–20");
  if (!integer(a.majorEveryX, 1, 200) || !integer(a.majorEveryY, 1, 200) ||
      !integer(a.minorDivisionsX, 1, 20) || !integer(a.minorDivisionsY, 1, 20))
    throw new Error("Independent major/minor intervals are outside the supported range");
  if (!["auto", "on", "off"].includes(a.rulerMode)) throw new Error("Invalid fine-cell ruler setting");
  if (!integer(a.a1Row, 0, 99999) || !integer(a.a1Col, 0, 99999))
    throw new Error("A1 anchor must be a valid nonnegative grid cell");
  if (!(a.cellSize === null || finite(a.cellSize, 10, 2000))) throw new Error("Legacy cell size must be 10–2000 pixels");
  if (!(a.cellWidth === null || finite(a.cellWidth, 10, 2000)) ||
      !(a.cellHeight === null || finite(a.cellHeight, 10, 2000)))
    throw new Error("Gridlines cell width and height must each be 10–2000 pixels");
  if (typeof a.linkCellDimensions !== "boolean") throw new Error("Invalid linked cell setting");
  if (a.linkCellDimensions && a.cellWidth !== a.cellHeight)
    throw new Error("Linked cells require equal width and height; unlink them for rectangles");
  if (!finite(a.offsetX, -20000, 20000) || !finite(a.offsetY, -20000, 20000)) throw new Error("Gridlines offset is outside the supported range");
  if (!/^#[0-9a-f]{6}$/i.test(a.color)) throw new Error("Invalid gridline color");
  if (!finite(a.alpha, 0, 1) || !finite(a.majorWidth, .25, 20) || !finite(a.minorWidth, .25, 20))
    throw new Error("Invalid gridline opacity or line width");
  if (!["top", "bottom", "both", "off"].includes(a.colLabelPosition) ||
      !["left", "right", "both", "off"].includes(a.rowLabelPosition))
    throw new Error("Invalid row or column label placement");
  if (![a.colLabelSize,a.rowLabelSize,a.subLabelSize].every(n => integer(n, 7, 48)))
    throw new Error("Column, row and subcell label sizes must be 7–48px");
  if (![a.colLabelColor,a.rowLabelColor,a.subLabelColor].every(c => /^#[0-9a-f]{6}$/i.test(c)))
    throw new Error("Invalid coordinate font color");
  return a;
}

export function overlayGeometryChanged(before, after, nativeSizeX, nativeSizeY = nativeSizeX) {
  const a = normalizeAxes(before), b = normalizeAxes(after);
  const effectiveX = x => x.cellWidth ?? nativeSizeX;
  const effectiveY = x => x.cellHeight ?? nativeSizeY;
  // A1 changes coordinate meanings and major-line positions, even though fine-cell geometry stays put.
  return effectiveX(a) !== effectiveX(b) || effectiveY(a) !== effectiveY(b) ||
    a.offsetX !== b.offsetX || a.offsetY !== b.offsetY ||
    a.a1Row !== b.a1Row || a.a1Col !== b.a1Col;
}


/** Only geometry-affecting fields are fingerprinted. Grid color/distance should not trigger a review. */
export function geometrySnapshot(scene) {
  const dimensions = scene.getDimensions?.() ?? scene.dimensions;
  const rect = dimensions?.sceneRect;
  const grid = scene.grid;
  if (!rect || !grid) throw new Error("Scene geometry is not available");
  const topCell = grid.getOffset?.({x: rect.x + .5, y: rect.y + .5});
  const vertices = topCell && grid.getVertices?.(topCell);
  const topLeft = vertices?.length ? {
    x: Math.min(...vertices.map(p => p.x)), y: Math.min(...vertices.map(p => p.y))
  } : {x: rect.x, y: rect.y};
  const snap = {
    type: Number(scene._source?.grid?.type ?? scene.grid?.type ?? -1),
    size: Number(scene._source?.grid?.size ?? grid.size),
    width: Number(scene.width ?? dimensions.sceneWidth),
    height: Number(scene.height ?? dimensions.sceneHeight),
    padding: Number(scene.padding ?? 0),
    sceneX: Number(rect.x), sceneY: Number(rect.y),
    gridOriginX: Number(topLeft.x - rect.x), gridOriginY: Number(topLeft.y - rect.y)
  };
  return snap;
}

export function geometryChanged(a, b) {
  if (!a || !b) return true;
  return ["type", "size", "width", "height", "padding", "sceneX", "sceneY", "gridOriginX", "gridOriginY"].some(k => a[k] !== b[k]);
}

export function newState(snapshot) {
  return {
    schemaVersion: SCHEMA_VERSION,
    revision: 1,
    geometryRevision: 1,
    baseline: snapshot,
    axes: {...DEFAULT_AXES},
    playerGridVisible: false, // Explicit GM opt-in, independent from per-shading visibility.
    formats: [],
    namedRanges: []
  };
}

export function validateState(value) {
  if (!value || value.schemaVersion !== SCHEMA_VERSION || !Array.isArray(value.formats) || !Array.isArray(value.namedRanges) || !value.baseline) {
    throw new Error("Gridlines Scene data is missing or from an unsupported schema; no changes were saved");
  }
  if (!Number.isInteger(value.revision) || value.revision < 1 || !Number.isInteger(value.geometryRevision) || value.geometryRevision < 1) throw new Error("Invalid Gridlines revision");
  if (value.formats.length > MAX_FORMATS || value.namedRanges.length > MAX_RANGES) throw new Error("Gridlines Scene data exceeds the prototype limits");
  validateAxes(value.axes);
  if (value.playerGridVisible !== undefined && typeof value.playerGridVisible !== "boolean")
    throw new Error("Invalid player grid visibility setting");
  for (const layer of value.formats) {
    if (layer.playerVisible !== undefined && typeof layer.playerVisible !== "boolean")
      throw new Error("Invalid shading player visibility setting");
  }
  return value;
}

export function alignmentStatus(state, sceneSnapshot) {
  if (!state) return {pending: false};
  return {pending: geometryChanged(state.baseline, sceneSnapshot), before: state.baseline, after: sceneSnapshot};
}

export function remapRangeByPixels(range, previous, current) {
  if (!previous || !current || previous.type !== current.type) throw new Error("Different grid types require a manual review");
  if (previous.width !== current.width || previous.height !== current.height) throw new Error("Scene dimensions changed; automatic remapping is unavailable");
  if (!(previous.size > 0 && current.size > 0)) throw new Error("Invalid grid sizes");
  const rect = normalizeRange(range.from, range.to);
  const convert = (n, oldOrigin, newOrigin, oldSize, newSize) => Math.floor((oldOrigin + n * oldSize - newOrigin + .00001) / newSize);
  const ending = (n, oldOrigin, newOrigin, oldSize, newSize) => Math.floor((oldOrigin + (n + 1) * oldSize - newOrigin - .00001) / newSize);
  const from = {
    row: convert(rect.from.row, previous.gridOriginY, current.gridOriginY, previous.size, current.size),
    col: convert(rect.from.col, previous.gridOriginX, current.gridOriginX, previous.size, current.size)
  };
  const to = {
    row: ending(rect.to.row, previous.gridOriginY, current.gridOriginY, previous.size, current.size),
    col: ending(rect.to.col, previous.gridOriginX, current.gridOriginX, previous.size, current.size)
  };
  const maxRow = Math.ceil(current.height / current.size) - 1;
  const maxCol = Math.ceil(current.width / current.size) - 1;
  if (from.row < 0 || from.col < 0 || to.row > maxRow || to.col > maxCol) throw new Error("At least one range would leave the Scene; manual review required");
  return normalizeRange(from, to);
}

export function previewPixelRemap(state, currentSnapshot) {
  validateState(state);
  const changes = [];
  const transform = (entry, type) => {
    const next = remapRangeByPixels(entry.range, state.baseline, currentSnapshot);
    changes.push({type, name: entry.name ?? entry.id, before: formatRange(entry.range), after: formatRange(next)});
    return {...entry, range: next};
  };
  return {
    changes,
    state: {
      ...state,
      namedRanges: state.namedRanges.map(n => transform(n, "Named range")),
      formats: state.formats.map(f => transform(f, "Fill"))
    }
  };
}

export function addNamedRange(state, name, range, id) {
  const clean = String(name ?? "").trim();
  if (!clean || clean.length > 64 || /[\x00-\x1F]/.test(clean)) throw new Error("Name must contain 1–64 ordinary characters");
  if (state.namedRanges.some(item => item.name.toLocaleLowerCase() === clean.toLocaleLowerCase())) throw new Error("A range with that name already exists on this Scene");
  if (state.namedRanges.length >= MAX_RANGES) throw new Error("This Scene has reached the named-range limit");
  state.namedRanges.push({id, name: clean, range: normalizeRange(range.from, range.to)});
}

/** Rename/delete a saved name without altering its immutable ID, area, or shading. */
export function renameNamedRange(state, id, name) {
  const entry = state.namedRanges.find(item => item.id === id);
  if (!entry) throw new Error("Named area no longer exists; refresh Gridlines+");
  const clean = String(name ?? "").trim();
  if (!clean || clean.length > 64 || /[\x00-\x1F]/.test(clean))
    throw new Error("Name must contain 1–64 ordinary characters");
  if (state.namedRanges.some(item => item.id !== id && item.name.toLocaleLowerCase() === clean.toLocaleLowerCase()))
    throw new Error("A range with that name already exists on this Scene");
  entry.name = clean;
}

export function removeNamedRange(state, id) {
  const before = state.namedRanges.length;
  state.namedRanges = state.namedRanges.filter(entry => entry.id !== id);
  if (state.namedRanges.length === before) throw new Error("Named area no longer exists; refresh Gridlines+");
}

export function addFill(state, range, color, opacity, id) {
  if (state.formats.length >= MAX_FORMATS) throw new Error("This Scene has reached the formatting limit");
  if (!/^#[0-9A-Fa-f]{6}$/.test(color) || !Number.isFinite(opacity) || opacity < 0 || opacity > 1) throw new Error("Invalid fill style");
  state.formats.push({id, range: normalizeRange(range.from, range.to), fill: color, opacity, playerVisible: false});
}

/** Split a rectangle around a removed intersection; no grid documents are created. */
export function subtractRange(source, cut) {
  const a = normalizeRange(source.from, source.to);
  const b = normalizeRange(cut.from, cut.to);
  const top = Math.max(a.from.row, b.from.row), bottom = Math.min(a.to.row, b.to.row);
  const left = Math.max(a.from.col, b.from.col), right = Math.min(a.to.col, b.to.col);
  if (top > bottom || left > right) return [a];
  const pieces = [];
  const add = (r0, c0, r1, c1) => {
    if (r0 <= r1 && c0 <= c1) pieces.push(normalizeRange({row:r0,col:c0},{row:r1,col:c1}));
  };
  add(a.from.row, a.from.col, top - 1, a.to.col);
  add(bottom + 1, a.from.col, a.to.row, a.to.col);
  add(top, a.from.col, bottom, left - 1);
  add(top, right + 1, bottom, a.to.col);
  return pieces;
}

export function previewClearShading(state, selected) {
  validateState(state);
  let affected = 0, resulting = 0;
  for (const item of state.formats) {
    const remaining = subtractRange(item.range, selected);
    if (remaining.length !== 1 || JSON.stringify(remaining[0]) !== JSON.stringify(normalizeRange(item.range.from,item.range.to))) affected++;
    resulting += remaining.length;
  }
  return {affected, previous: state.formats.length, resulting};
}

/** Remove shading only inside selected cells, preserving adjacent fragments and named ranges. */
export function clearShadingInSelection(state, selected, makeId) {
  const preview = previewClearShading(state, selected);
  if (preview.resulting > MAX_FORMATS) throw new Error("Clearing this selection would exceed the shading-layer limit; remove individual layers first");
  const remaining = [];
  const seen = new Set(state.formats.map(f => f.id));
  for (const format of state.formats) {
    const fragments = subtractRange(format.range, selected);
    fragments.forEach((range, i) => {
      const id = i === 0 ? format.id : makeId();
      if (seen.has(id) && id !== format.id) throw new Error("Generated shading fragment ID already exists");
      seen.add(id);
      remaining.push({...format, id, range});
    });
  }
  state.formats = remaining;
  return preview;
}

/** GM opt-in publication of geometry and labels on a per-Scene basis. */
export function setPlayerGridVisible(state, visible) {
  if (typeof visible !== "boolean") throw new Error("Player grid visibility must be on or off");
  state.playerGridVisible = visible;
}

/** A shading layer is never automatically published: old records default to hidden. */
export function setShadingPlayerVisible(state, id, visible) {
  if (typeof visible !== "boolean") throw new Error("Shading player visibility must be on or off");
  const layer = state.formats.find(f => f.id === id);
  if (!layer) throw new Error("Shading layer no longer exists; refresh Gridlines+");
  layer.playerVisible = visible;
}

/**
 * Player rendering projection. Never expose named-range labels or GM-only shading
 * through the module's public overlay state/API. The raw Scene flag is NOT an
 * access-control boundary; genuinely confidential notes do not belong there.
 * Individual published shades remain visible if coordinate-grid sharing is off.
 */
export function projectPlayerView(state) {
  if (!state) return null;
  validateState(state);
  const showGrid = state.playerGridVisible === true;
  const shading = state.formats.filter(f => f.playerVisible === true);
  if (!showGrid && !shading.length) return null;
  return {
    schemaVersion: SCHEMA_VERSION,
    revision: state.revision,
    geometryRevision: state.geometryRevision,
    baseline: structuredClone(state.baseline),
    axes: {...normalizeAxes(state.axes), enabled: showGrid && normalizeAxes(state.axes).enabled,
      labels: showGrid && normalizeAxes(state.axes).labels},
    formats: shading.map(f => ({range: structuredClone(f.range), fill: f.fill, opacity: f.opacity})),
    namedRanges: []
  };
}

/** Remove a single saved shading layer by ID; no other overlays or ranges change. */
/** Configure one existing shading layer without replacing its ID, extent, or unrelated layers. */
export function updateShadingLayer(state, id, {label = "", fill, opacity}) {
  const layer = state.formats.find(f => f.id === id);
  if (!layer) throw new Error("Shading layer no longer exists; refresh Gridlines+");
  const name=String(label ?? "").trim();
  if (name.length > 64 || /[\x00-\x1F]/.test(name)) throw new Error("Shading label must contain at most 64 ordinary characters");
  if (!/^#[0-9a-f]{6}$/i.test(fill) || !Number.isFinite(opacity) || opacity < 0 || opacity > 1)
    throw new Error("Invalid shading color or opacity");
  layer.fill=fill;
  layer.opacity=opacity;
  if (name) layer.label=name;
  else delete layer.label;
}

export function clearShadingLayer(state, id) {
  const before = state.formats.length;
  state.formats = state.formats.filter(f => f.id !== id);
  if (state.formats.length === before) throw new Error("Shading layer no longer exists; refresh Gridlines+");
}

export function clearAllShading(state) {
  const count = state.formats.length;
  state.formats = [];
  return count;
}
